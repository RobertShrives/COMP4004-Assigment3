package cucumber.runtime.formatter;

public interface ColorAware {
    void setMonochrome(boolean monochrome);
}
