package cucumber.api;

public interface Plugin {
}
