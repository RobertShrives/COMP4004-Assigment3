package cucumber.runtime.formatter;

public interface StrictAware {
    public void setStrict(boolean strict);
}
