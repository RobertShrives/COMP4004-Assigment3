package cucumber.api;

public interface SummaryPrinter {
    public void print(cucumber.runtime.Runtime runtime);
}
