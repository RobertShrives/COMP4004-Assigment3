# clojure-cukes

Just a little example illustrating how to use Cucumber with Clojure and Leiningen. Please note that the example uses https://github.com/nilswloka/lein-cucumber, which requires Leiningen 2.

## Running cukes

```
lein deps
lein cucumber
```