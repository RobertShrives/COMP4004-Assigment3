package cucumber.examples.java.paxexam;

public interface CalculatorService {

    int add(int a, int b);

}
