package cucumber.api.guice;


/**
 * Please see package documentation in package.html
 */
public class README {
}
