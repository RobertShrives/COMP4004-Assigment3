# Using Cucumber Guice

The package documentation contains detailed instructions for using Cucumber Guice. In particular be sure to read the 
migration section if upgrading from earlier versions of Cucumber Guice.

[Read package documentation online at cukes.info]
(http://cukes.info/api/cucumber/jvm/javadoc/cucumber/api/guice/package-summary.html) 

[Read package documentation offline (raw html)](src/main/java/cucumber/api/guice/package.html)
