package cucumber.runtime.groovy

class WorldWithPropertyAndMethod {
    def aProperty
    void aMethod(List<Integer> args) {}
}
