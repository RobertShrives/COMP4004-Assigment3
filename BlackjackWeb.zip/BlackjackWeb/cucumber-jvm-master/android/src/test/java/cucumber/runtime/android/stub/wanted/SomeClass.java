package cucumber.runtime.android.stub.wanted;

public class SomeClass {
}
